const { webhookHandler } = require("./bot");

exports.handler = async (event) => {
  return await webhookHandler(event);
};
